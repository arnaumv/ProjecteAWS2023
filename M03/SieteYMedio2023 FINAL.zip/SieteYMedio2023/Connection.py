import pymysql
host = "20.86.76.157"
user = "proyecto"
password = "P@ssw0rd12345"
database = "sieteymedioDB"

conn=pymysql.connect(host=host,user=user, password=password,database=database)
cur = conn.cursor()


query='select * from jugadores'

cur.execute(query)

rows=cur.fetchall()

print(rows)