import random

import pymysql
conn=pymysql.connect(host="20.86.76.157",user="proyecto", password="P@ssw0rd12345",database="sieteymedioDB")
cur = conn.cursor()


player_game = {'cardgame_id':{'id_jugador':{'initial_card_id':"", 'starting_points': "", 'ending_points':"",}}}

cardgame = {'cardgame_id': "", 'players': "Numero de jugadores",
'start_hour':"Hora de inicio de artida ( datetime)", 'rounds': "Número de rondas", 'end_hour': "hora final de partida ( datetime)" }

player_game_round = {'round':{'id_jugaador':{'is_bank':"0 ó 1"",'bet_points': "",'starting_round_points':"",'cards_value':"",'endind_round_points':"""}}}
menu01 = "\n" + " " * 63 + "1) New Human Player".ljust(60) + "\n" + " " * 63 + \
         "2) New Boot".ljust(60) + "\n" + " " * 63 + \
         "3) Show/Remove Players".ljust(60) + "\n" + " " * 63 + \
         "4) Go Back".ljust(60)
menu02 = "\n" + " " * 63 + "1) Set Game Players".ljust(60) + "\n" + " " * 63 + \
         "2) Set Card's Deck (Default Spanish Deck)".ljust(60) + "\n" + " " * 63 + \
         "3) Set Max Rounds (Default 5 Rounds)".ljust(60) + "\n" + " " * 63 + \
         "4) Go Back".ljust(60)


def getOpt(textOpts,inputOptText,rangeList,exceptions):
 while True:
     print(textOpts)                 ### CON ESTA FUNCION LE PASAMOS UN TEXTO Y NOS PEDIRA QUE INTRODUZCAMOS UNA OPCIÓN QUE SI ESTA NO ESTA EN EL
                                      ##      RANGO QUE HEMOS DEFINIDO NOS DIRA QUE LA OPCIÓN ES INCORRECTA Y NOS MOSTRARÁ DE NUEVO EL TEXTO ##
     opc = input(inputOptText)
     if opc not in rangeList and opc not in exceptions:
         print("*"*5,"Invalid Option","*"*5)
         input("Press enter to continue")
     else:
        return opc


def fill_player_game(player_game, gameID, *fields):
    #Asignar valores a las claves del diccionario
    player_game["game_id"] = gameID
    for field in fields:
        key, value = field.split(":")
        player_game[key.strip()] = value.strip()


def insertBBDD_player_game(player_game, cardgame_id):
    #cur = conn.cursor()

    # Insertar datos en la tabla player_game
    sql = f"INSERT INTO player_game (cardgame_id, id_jugador, initial_card_id, starting_points, ending_points) VALUES (?,?,?,?)"

    #cur.execute(sql)
    #conn.commit()

def insertBBDDCardgame(cardgame):
    #cur = conn.cursor()

    # Insertar datos en la tabla player_game
    #sql = f"INSERT INTO cardgame (cardgame_id, players, rounds, start_hour, end_hour) VALUES (?,?,?,?)"
        # (cardgame["cardgame_id"], 'players', 'rounds', ' start_hour', 'end_hour')
    print("hola")
    #cur.execute(sql)
    #conn.commit()


def fill_player_game_round(player_game_round, round, *fields):
    player_game_round[round] = {}
    for i in range(0, len(fields), 6):
        id_player_1 = fields[i]
        is_bank = fields[i + 1]
        bet_points = fields[i + 2]
        starting_round_points = fields[i + 3]
        cards_value = fields[i + 4]
        endind_round_points = fields[i + 5]

        player_game_round[round][id_player_1] = {
            "is_bank": is_bank,
            "bet_points": bet_points,
            "starting_round_points": starting_round_points,
            "cards_value": cards_value,
            "endind_round_points": endind_round_points
        }


def setGamePriority(mazo, contextGame=None):
    # Mezclar las cartas del mazo
    random.shuffle(mazo)
    # Repartir una carta a cada jugador
    cartas_repartidas = {}
    for jugador in contextGame["game"]:
        carta = mazo.pop()
        cartas_repartidas[jugador] = carta
        # Ordenar la lista de jugadores según la carta recibida
        contextGame["game"] = sorted(contextGame["game"], key=lambda x: cartas_repartidas[x])
    # Establecer las prioridades
    for i, jugador in enumerate(contextGame["game"]):
        contextGame["game"][i]["priority"] = i+1
    return contextGame["game"]


def resetPoints(contextGame=None):
    for jugador in contextGame["game"]:
     jugador["points"] = 20
    return contextGame["game"]


def checkMinimun2PlayerWithPoints(players):
    player_with_points = 0
    for player in players:
        if player['points'] > 0:
            player_with_points += 1
    if player_with_points >= 2:
        return True
    else:
        return False



def humanRound(id, mazo):
    while True:
        print("Player", id)
        print("1) View Stats")
        print("2) View Game Stats")
        print("3) Set Bet")
        print("4) Order Card")
        print("5) Automatic Play")
        print("6) Stand")
        option = input("Option: ")
        if option == "1":
            # View Stats option
            pass
        elif option == "2":
            # View Game Stats option
            pass
        elif option == "3":
            # Set Bet option
            pass
        elif option == "4":
            # Order Card option
            card = mazo.pop()
            print("You received the card", card)
        elif option == "5":
            # Automatic Play option
            pass
        elif option == "6":
            # Stand option
            return
        else:
            print("Invalid option, try again.")


def maxRounds():
    rounds_ok = False
    while not rounds_ok:
        try:
            rounds = input("\n\n" + " " * 50 + "Select the max of rounds for the next game (5-30):\n" + " " * 50 + "> ")
            if not rounds.isdigit():
                raise TypeError
            rounds = int(rounds)
            if rounds < 5 or rounds > 30:
                raise ValueError
            else:
                rounds_ok = True
                return rounds
        except ValueError:
            print("\n" + " " * 50 + "That's not a valid number!")
            input(" " * 50 + "Press ENTER to continue...")
        except TypeError:
            print('\n' + " " * 50 + "That's not a number!")
            input(" " * 50 + "Press ENTER to continue...")



def gameTitle():
    print("*" * 120)
    print("    //   ) )   //   / / ||   / /   //   / /   /|    / /     // | |     /|    / /     //    ) )     //    / /   // | |     / /        //   / /")
    print("   ((         //____    ||  / /   //____     //|   / /     //__| |    //|   / /     //    / /     //___ / /   //__| |    / /        //___")
    print("     \\      / ____     || / /   / ____     // |  / /     //   | |   //  | / /     //    / /     //    / /   //    | |  / /        //")
    print("((___ / /   //____/ /    |  /   //____/ /  //   |/ /     //    | |  //   |/ /     //____/ /     //    / /   //     | | / /____/ / //")
    print("*" * 120)


def gameover():
    print("*" * 120)
    print(" #####     ###    ##   ##  ######             #####   ###  ##  ####     ######")
    print("###       #####   ### ###  ##                ###  ##  ###  ##  ##       ###  ##")
    print("### ##    ## ##   #######  #####             ###  ##  ###  ##  #####    ###  ##")
    print("###  ##  ##   ##  #######  ##                ###  ##  ###  ##  ##       #######")
    print("###  ##  ##   ##  #######  ##                ###  ##  ###  ##  ##       ######")
    print("#######  ## ####  ###  ##  #######           #######   #####   #######  ### ###")
    print("#######  ## ####  ###  ##  #######           #######   #####   #######  ### ###")
    print(" #####   ## ####  ###  ##  #######            #####     ###    #######  ### ###")
    print("*" * 120)


# def savePlayer(nif, name, risk, human):
#     conn = mydb.cursor()
#     sql = f"insert into jugadores (id_jugador, id_step_adventure, id_history,) values('{nif}','{name}', '{optionId}')"
#     conn.execute(sql)
#     conn.commit()
#     print("prueba")


def new_Nif():
    new = "yes"
    global letra

    try:
        nif = input("Introduce tu NIF: ")
        letra = nif[-1]
        validar_letra_nif(nif[:-1])     ### VALIDAMOS QUE LA LETRA SEA CORRECTA CON ESTA FUNCION ##
        while nif[-1] in num:
            print("")
            new_Nif()
        return nif
    except ValueError:    ### SIEMPRE QUE EL NIF NO TENGA  8 NUMEROS Y UNA LETRA MOSTARA EL ERROR DEL TIPO 'VALUE ERROR' ##
        print("El NIF tiene que tener 8 digitos y letra")
    new_Nif()
num = '0123456789 '

def validar_letra_nif(nif):
    letras = 'TRWAGMYFPDXBNJZSQVHLCKE'
    valor = int(nif) % 23
    if letra.upper() == letras[valor]:
        print("Dni es correcto")
    else:
        print("Letra incorrecta")

def set_type():
    txt = ("Select your profile:\n1) Cautious\n2) Moderated\n3) Bold")
    opt = "\nChoose your Option:"
    lista = ["1", "2", "3"]
    exc = []
    opc = getOpt(txt, opt, lista, exc)


    if opc == 1:
        # son 30 puntos
        type = 30
        return type
    elif opc == 2:
        # son 40p
        type = 40
        return type
    elif opc == 3:
        # son 50p
        type = 50
        return type
def crear_nombre():
    nombre_ok = False
    while not nombre_ok:
        try:
            nombre = input("Insert Name: ")
            if nombre.isspace() or nombre == "":
                raise TypeError("Incorrect typing")
            else:
                return nombre

        except TypeError:
            print("Space-only or empty names are not allowed. Type Name Again.")


def InsertUser(nif,name):
    #type daba error #
    cur = conn.cursor()
    sql = f"insert into jugadores (id_jugador, player_name, player_risk, human) values('{nif}','{name}', '{1}', {1})"

    cur.execute(sql)
    conn.commit()


def menu_01():    #### MENU ADD PLAYER.... ####
    dejar_este_nivel = False
    while not dejar_este_nivel:
        opcion_ok = False
        opc = ''
        while not opcion_ok:
            print(menu01)
            opc = input("\n" + " " * 63 + "Option: " + "\n" + " " * 63 )
            if not opc.isdigit():
                print("== Opcion Incorrecta!!! ===")
            elif int(opc) < 1 or int(opc) > 4:
                print("== Opcion Incorrecta!!! ===")
            else:
                opcion_ok = True
                opc = int(opc)
        if opc == 1:
            print("New Human Player")
            nif = new_Nif()
            name = crear_nombre()
            #type = set_type()  Hay que arreglarlo ##
            InsertUser(nif,name)
        elif opc == 2:
            print("New Boot")
        elif opc == 3:
            print("Show/Remove players")

            cur = conn.cursor()
            query = 'select * from jugadores'
            cur.execute(query)
            rows = cur.fetchall()


            jugadores = {}
            humans = {}
            bots = {}

            for x in rows:  # Los almacenamos a todos en un diccionario genérico
                player_id = x[0]
                player_name = x[1]
                player_risk = x[2]
                que_es = x[3]
                jugadores[player_id] = {'player_name': player_name, 'player_risk': player_risk, 'bot': que_es}

            for dni, datos_jugador in jugadores.items():  # Los separamos por humanos/bots
                if datos_jugador['bot'] == 0:
                    humans[dni] = datos_jugador
                else:
                    bots[dni] = datos_jugador

            contador_humanos = 0
            contador_bots = 0
            for dni in humans:
                contador_humanos += 1
            for dni in bots:
                contador_bots += 1

            if contador_humanos > contador_bots:
                veces_printear = contador_humanos
            elif contador_humanos < contador_bots:
                veces_printear = contador_bots
            elif contador_humanos == contador_bots:
                veces_printear = contador_humanos

            item_str = "*" * 50 + "Select Players" + "*" * 49 + "\n" \
                                                                "———————————————————————————————————————————————————————————————————————————————————————————————————————\n" \
                                                                "ID              Name              Type              ||   ID              Name              Type\n" \
                                                                "———————————————————————————————————————————————————————————————————————————————————————————————————————\n"

            item_str += "papa".rjust(4) + "            " + "papa".ljust(12) + "papa".rjust(10) + "||".rjust(16) + \
                        str(player_id).rjust(7) + player_name.rjust(16) + str(player_risk).rjust(18)

            print("\n" + item_str)
            for x in range(0, veces_printear):
                print

            print("Menú de veure tots els jugadors i bots, eliminar també.")
            input()
        elif opc == 4:
            dejar_este_nivel = True


def menu_02():    #### MENU SETTINGS ####
    dejar_este_nivel = False
    while not dejar_este_nivel:
        opcion_ok = False
        opc = ''
        while not opcion_ok:
            print(menu02)
            opc = input("\n" + " " * 63 + "Option: " + "\n" + " " * 63 )
            if not opc.isdigit():
                print("== Opcion Incorrecta!!! ===")
            elif int(opc) < 1 or int(opc) > 4:
                print("== Opcion Incorrecta!!! ===")
            else:
                opcion_ok = True
                opc = int(opc)
        if opc == 1:
            print("Option 2.1 ")

        if opc == 2:
            print("Set Card's Deck (Default Spanish Deck)")

        if opc == 3:
            print("Max Rounds")
        if opc == 4:

            dejar_este_nivel = True



