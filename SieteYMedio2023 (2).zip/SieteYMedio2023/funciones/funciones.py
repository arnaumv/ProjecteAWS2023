import random

import pymysql
conn=pymysql.connect(host="20.86.76.157",user="proyecto", password="P@ssw0rd12345",database="sieteymedioDB")
cur = conn.cursor()
players = {
    "11115555A": {"name": "Arnau", "human": True, "bank": False, "initialCard": "", "priority": 0
        , "type": 40, "bet": 4, "points": 0, "cards": [], "roundPoints": 0},
    "22225555A": {"name": "Alex", "human": True, "bank": False, "initialCard": "", "priority": 0
        , "type": 40, "bet": 4, "points": 0, "cards": [], "roundPoints": 0}}

player_game = {'cardgame_id':{'id_jugador':{'initial_card_id':"", 'starting_points': "", 'ending_points':"",}}}

cardgame = {'cardgame_id': "", 'players': "Numero de jugadores",
'start_hour':"Hora de inicio de artida ( datetime)", 'rounds': "Número de rondas", 'end_hour': "hora final de partida ( datetime)" }

player_game_round = {'round':{'id_jugaador':{'is_bank':"0 ó 1"",'bet_points': "",'starting_round_points':"",'cards_value':"",'endind_round_points':"""}}}
menu01 = "\n" + " " * 60 + "1) New Human Player".ljust(60) + "\n" + " " * 60 + \
         "2) New Boot".ljust(60) + "\n" + " " * 60 + \
         "3) Show/Remove Players".ljust(60) + "\n" + " " * 60 + \
         "4) Go Back".ljust(60)
menu02 = "\n" + " " * 60 + "1) Set Game Players".ljust(60) + "\n" + " " * 60+ \
         "2) Set Card's Deck (Default Spanish Deck)".ljust(60) + "\n" + " " * 60 + \
         "3) Set Max Rounds (Default 5 Rounds)".ljust(60) + "\n" + " " * 60 + \
         "4) Go Back".ljust(60)


def getOpt(textOpts,inputOptText,rangeList,exceptions):
 while True:
     print(textOpts)                 ### CON ESTA FUNCION LE PASAMOS UN TEXTO Y NOS PEDIRA QUE INTRODUZCAMOS UNA OPCIÓN QUE SI ESTA NO ESTA EN EL
                                      ##      RANGO QUE HEMOS DEFINIDO NOS DIRA QUE LA OPCIÓN ES INCORRECTA Y NOS MOSTRARÁ DE NUEVO EL TEXTO ##
     opc = input(inputOptText)
     if opc not in rangeList and opc not in exceptions:
         print("*"*5,"Invalid Option","*"*5)
         input("Press enter to continue")
     else:
        return opc


def fill_player_game(player_game, gameID, *fields):
    #Asignar valores a las claves del diccionario
    player_game["game_id"] = gameID
    for field in fields:
        key, value = field.split(":")
        player_game[key.strip()] = value.strip()


def insertBBDD_player_game(player_game, cardgame_id):
    #cur = conn.cursor()

    # Insertar datos en la tabla player_game
    sql = f"INSERT INTO player_game (cardgame_id, id_jugador, initial_card_id, starting_points, ending_points) VALUES (?,?,?,?)"

    #cur.execute(sql)
    #conn.commit()

def insertBBDDCardgame(cardgame):
    #cur = conn.cursor()

    # Insertar datos en la tabla player_game
    #sql = f"INSERT INTO cardgame (cardgame_id, players, rounds, start_hour, end_hour) VALUES (?,?,?,?)"
        # (cardgame["cardgame_id"], 'players', 'rounds', ' start_hour', 'end_hour')
    print("hola")
    #cur.execute(sql)
    #conn.commit()


def fill_player_game_round(player_game_round, round, *fields):
    player_game_round[round] = {}
    for i in range(0, len(fields), 6):
        id_player_1 = fields[i]
        is_bank = fields[i + 1]
        bet_points = fields[i + 2]
        starting_round_points = fields[i + 3]
        cards_value = fields[i + 4]
        endind_round_points = fields[i + 5]

        player_game_round[round][id_player_1] = {
            "is_bank": is_bank,
            "bet_points": bet_points,
            "starting_round_points": starting_round_points,
            "cards_value": cards_value,
            "endind_round_points": endind_round_points
        }


def setGamePriority(mazo, contextGame=None):
    # Mezclar las cartas del mazo
    random.shuffle(mazo)
    # Repartir una carta a cada jugador
    cartas_repartidas = {}
    for jugador in contextGame["game"]:
        carta = mazo.pop()
        cartas_repartidas[jugador] = carta
        # Ordenar la lista de jugadores según la carta recibida
        contextGame["game"] = sorted(contextGame["game"], key=lambda x: cartas_repartidas[x])
    # Establecer las prioridades
    for i, jugador in enumerate(contextGame["game"]):
        contextGame["game"][i]["priority"] = i+1
    return contextGame["game"]


def resetPoints(contextGame=None):
    for jugador in contextGame["game"]:
     jugador["points"] = 20
    return contextGame["game"]


def checkMinimun2PlayerWithPoints(players):
    player_with_points = 0
    for player in players:
        if player['points'] > 0:
            player_with_points += 1
    if player_with_points >= 2:
        return True
    else:
        return False



def humanRound(id, mazo):
    while True:
        print("Player", id)
        print("1) View Stats")
        print("2) View Game Stats")
        print("3) Set Bet")
        print("4) Order Card")
        print("5) Automatic Play")
        print("6) Stand")
        option = input("Option: ")
        if option == "1":
            # View Stats option
            pass
        elif option == "2":
            # View Game Stats option
            pass
        elif option == "3":
            # Set Bet option
            pass
        elif option == "4":
            # Order Card option
            card = mazo.pop()
            print("You received the card", card)
        elif option == "5":
            # Automatic Play option
            pass
        elif option == "6":
            # Stand option
            return
        else:
            print("Invalid option, try again.")


def maxRounds():
    rounds_ok = False
    while not rounds_ok:
        try:
            rounds = input("\n\n" + " " * 50 + "Select the max of rounds for the next game (5-30):\n" + " " * 50 + "> ")
            if not rounds.isdigit():
                raise TypeError
            rounds = int(rounds)
            if rounds < 5 or rounds > 30:
                raise ValueError
            else:
                rounds_ok = True
                return rounds
        except ValueError:
            print("\n" + " " * 50 + "That's not a valid number!")
            input(" " * 50 + "Press ENTER to continue...")
        except TypeError:
            print('\n' + " " * 50 + "That's not a number!")
            input(" " * 50 + "Press ENTER to continue...")



def gameTitle():
    print("""********************************************************************************************************************************************
                                         _____                         ___              __   __  __      ______
                                        / ___/___ _   _____  ____     /   |  ____  ____/ /  / / / /___ _/ / __/
                                        \__ \/ _ \ | / / _ \/ __ \   / /| | / __ \/ __  /  / /_/ / __ `/ / /_  
                                       ___/ /  __/ |/ /  __/ / / /  / ___ |/ / / / /_/ /  / __  / /_/ / / __/ 
                                      /____/\___/|___/\___/_/ /_/  /_/  |_/_/ /_/\__,_/  /_/ /_/\__,_/_/_/  
                             
    ********************************************************************************************************************************************""")


def gameover():
    print("*" * 120)
    print(" #####     ###    ##   ##  ######             #####   ###  ##  ####     ######")
    print("###       #####   ### ###  ##                ###  ##  ###  ##  ##       ###  ##")
    print("### ##    ## ##   #######  #####             ###  ##  ###  ##  #####    ###  ##")
    print("###  ##  ##   ##  #######  ##                ###  ##  ###  ##  ##       #######")
    print("###  ##  ##   ##  #######  ##                ###  ##  ###  ##  ##       ######")
    print("#######  ## ####  ###  ##  #######           #######   #####   #######  ### ###")
    print("#######  ## ####  ###  ##  #######           #######   #####   #######  ### ###")
    print(" #####   ## ####  ###  ##  #######            #####     ###    #######  ### ###")
    print("*" * 120)


# def savePlayer(nif, name, risk, human):
#     conn = mydb.cursor()
#     sql = f"insert into jugadores (id_jugador, id_step_adventure, id_history,) values('{nif}','{name}', '{optionId}')"
#     conn.execute(sql)
#     conn.commit()
#     print("prueba")


def new_Nif():
    new = "yes"
    global letra

    try:
        nif = input("Introduce tu NIF: ")
        letra = nif[-1]
        validar_letra_nif(nif[:-1])     ### VALIDAMOS QUE LA LETRA SEA CORRECTA CON ESTA FUNCION ##
        while nif[-1] in num:
            print("")
            new_Nif()
        return nif
    except ValueError:    ### SIEMPRE QUE EL NIF NO TENGA  8 NUMEROS Y UNA LETRA MOSTARA EL ERROR DEL TIPO 'VALUE ERROR' ##
        print("El NIF tiene que tener 8 digitos y letra")
    new_Nif()
num = '0123456789 '

def validar_letra_nif(nif):
    letras = 'TRWAGMYFPDXBNJZSQVHLCKE'
    valor = int(nif) % 23
    if letra.upper() == letras[valor]:
        print("Dni es correcto")
    else:
        print("Letra incorrecta")

def risk():
    txt = ("Select your profile:\n1) Cautious (30)\n2) Moderated (50) \n3) Bold (50)")

    opt = "\n" + " " * 60 + "Choose Your Option: " + "\n" + " " * 60
    lista = ["1", "2", "3"]
    exc = []
    opc = getOpt(txt, opt, lista, exc)
    txt = ("Select your profile:\n1) Cautious (30)\n2) Moderated (50) \n3) Bold (50)")
    if opc == "1":
        return 50
    if opc == "2":
        return 40
    if opc == "3":
        return 30








def crear_nombre():
    nombre_ok = False
    while not nombre_ok:
        try:
            nombre = input("\n" + " " * 60 + "Insert Name : " + "\n" + " " * 60)
            if nombre.isspace() or nombre == "":
                raise TypeError("\n" + " " * 60 + "Incorrect : " + "\n" + " " * 60)
            else:
                return nombre

        except TypeError:
            print("Space-only or empty names are not allowed. Type Name Again.")


# def InsertUser(nif,name,type):
#     #type daba error #
#     cur = conn.cursor()
#     sql = f"insert into jugadores (id_jugador, player_name, player_risk, human) values('{nif}','{name}', '{type}', %S)"
#
#     cur.execute(sql)
#     conn.commit()
def createPlayer():
    nif = new_Nif()
    name = crear_nombre()
    riesgo = risk()
    # if show_players(nif,name,riesgo):
    #     human = 1

    query = f"INSERT INTO jugadores VALUES ('{nif}','{name}',{riesgo},{1})"
    cur.execute(query)
    conn.commit()
    input("Jugador creado correctamente\nPulsa enter para continuar")

def createPlayerBot():
    nif = newRandomDNI()
    print("\n" + " " * 60 + "NIF Boot : " , nif,  + "\n" + " " * 60 )
    name = crear_nombre()
    riesgo = risk()
    # if show_players(nif,name,riesgo):
    #     human = 1

    query = f"INSERT INTO jugadores VALUES ('{nif}','{name}',{riesgo},{0})"
    cur.execute(query)
    conn.commit()
    input("Jugador creado correctamente\nPulsa enter para continuar")
def ShowNewPlayer(nif,name,risc):
    if risk() == 30:
        risc = "Prudente"
    elif risc == 40:
        risc = "Normal"
    else:
        risc = "Atrevido"
    cadena = 'DNI'.ljust(10) + '' + str(nif).rjust(30) + '\n' + 'Nombre'.ljust(10) + '' + str(name).rjust(
        30) + '\n' + 'Nivel de Riesgo'.ljust(10) + '' + risc.rjust(25) + '\n'
    print(cadena)
    opc = input('Es correcto? S/n\n> ')
    if opc.lower() == 's':
        return True
    else:
        return False


def menu_01():    #### MENU ADD PLAYER.... ####
    dejar_este_nivel = False
    while not dejar_este_nivel:
        opcion_ok = False
        opc = ''
        while not opcion_ok:
            print(menu01)
            opc = input("\n" + " " * 60 + "Option: " + "\n" + " " * 60 )
            if not opc.isdigit():
                print("== Opcion Incorrecta!!! ===")
            elif int(opc) < 1 or int(opc) > 4:
                print("== Opcion Incorrecta!!! ===")
            else:
                opcion_ok = True
                opc = int(opc)
        if opc == 1:
            print("\n" + " " * 60 + "New Human Player : " + "\n" + " " * 60 )
            # nif = new_Nif()
            # name = crear_nombre()
            createPlayer()

            #InsertUser(nif,name,type)
            # players[nif] = {"name": name, "human": True, "bank": False, "initialCard": "", "priority": 0
            #     , "type": type, "bet": 4, "points": 0, "cards": [], "roundPoints": 0}
            #print(players)
            print("Player saved!")
        elif opc == 2:
            print("\n" + " " * 60 + "Boot " + "\n" + " " * 60)
            createPlayerBot()
        elif opc == 3:
            print("Show/Remove players")
            show_players()

            cur = conn.cursor()
            query = 'select * from jugadores'
            cur.execute(query)
            rows = cur.fetchall()

            print(show_players_and_bots(myresult=rows))

            jugadores = {}

            for x in rows:  # Los almacenamos a todos en un diccionario genérico
                player_id = x[0]
                player_name = x[1]
                player_risk = x[2]
                que_es = x[3]
                jugadores[player_id] = {'player_name': player_name, 'player_risk': player_risk, 'bot': que_es}

            que_hacer, dni_borrar = remove_players_or_bots(jugadores=jugadores)
            if que_hacer == "y":
                sql = "DELETE FROM jugadores WHERE id_jugador = %s"
                adr = (dni_borrar[1:],)
                cur.execute(sql, adr)
                conn.commit()
                input('Player deleted succesfully. Press "ENTER" to continue...')
            elif que_hacer == "n":
                pass
            elif que_hacer == "-1":
                opc1 = None
                opc = None

        elif opc == 4:
            dejar_este_nivel = True


def remove_players_or_bots(jugadores=""):
    opc_ok = False
    while not opc_ok:
        opc = input(
            "\n                                                      Option ( -id to remove player, -1 to exit ):\n                                                      > ")
        if len(opc) != 10:
            if opc == "-1":
                return "-1"
            else:
                input('Your answer isn\'t correct. Please, press "ENTER" to continue...')
        else:
            while opc[1:9].isdigit() and opc[9].isalpha() and opc[:1] == '-':
                opc_sure = input("Are you sure you want to delete the selected profile? Y/y = Yes or N/n = No")
                if opc_sure.lower() == "y":
                    return "y", opc
                elif opc_sure.lower() == "n":
                    return "n"
                else:
                    input("Incorrect option. Press \"ENTER\" to continue...")
            else:
                input('Your answer isn\'t correct. Please, press "ENTER" to continue...')


jugadores = {
    '57760286H': {'player_name': 'wawa', 'player_risk': 50, 'bot': 0}
}



def show_players_and_bots(myresult="", jugadores={}, humans={}, bots={}):
    for x in myresult:  # Los almacenamos a todos en un diccionario genérico
        player_id = x[0]
        player_name = x[1]
        player_risk = x[2]
        que_es = x[3]
        jugadores[player_id] = {'player_name': player_name, 'player_risk': player_risk, 'bot': que_es}

    for dni, datos_jugador in jugadores.items():  # Los separamos por humanos/bots
        if datos_jugador['bot'] == 0:
            humans[dni] = datos_jugador
        else:
            bots[dni] = datos_jugador

    contador_humanos = 0
    contador_bots = 0
    for dni in humans:
        contador_humanos += 1
    for dni in bots:
        contador_bots += 1

    if contador_humanos > contador_bots:
        veces_printear = contador_humanos
    elif contador_humanos < contador_bots:
        veces_printear = contador_bots
    elif contador_humanos == contador_bots:
        veces_printear = contador_humanos

    print1_bots = 0
    print2_bots = 1
    print3_bots = 2
    print1_humans = 0
    print2_humans = 1
    print3_humans = 2

    lista_bots = []
    lista_humans = []

    item_str = "\n                                  " + "*" * 34 + " Select Players " + "*" * 34 + "\n" \
                                                                                                   "                                  ————————————————————————————————————————————————————————————————————————————————————\n" \
                                                                                                   "                                                   Bots                    ||                 Humans\n" \
                                                                                                   "                                  ————————————————————————————————————————————————————————————————————————————————————\n" \
                                                                                                   "                                   ID              Name              Type  ||  ID              Name              Type\n" \
                                                                                                   "                                  ————————————————————————————————————————————————————————————————————————————————————"

    for dni in bots:
        id_bots = dni
        name_bots = bots[dni]['player_name']
        type_bots = bots[dni]['player_risk']
        type_bots = str(type_bots)
        lista_bots.append(id_bots)
        lista_bots.append(name_bots)
        lista_bots.append(type_bots)

    for dni in humans:
        id_humans = dni
        name_humans = humans[dni]['player_name']
        type_humans = humans[dni]['player_risk']
        type_humans = str(type_humans)
        lista_humans.append(id_humans)
        lista_humans.append(name_humans)
        lista_humans.append(type_humans)

    len_humans = len(lista_humans)
    len_bots = len(lista_bots)

    if len_humans > len_bots:
        for i in range(len_bots, len_humans):
            lista_bots.append(' ')
    elif len_humans < len_bots:
        for i in range(len_humans, len_bots):
            lista_humans.append(' ')
    print(item_str)
    item_str2 = "                                   " + lista_bots[print1_bots].ljust(13) + '   ' + lista_bots[
        print2_bots].ljust(15) + '   ' + lista_bots[print3_bots].ljust(6) + "||  " + \
                lista_humans[print1_humans].ljust(13) + '   ' + lista_humans[print2_humans].ljust(15) + '   ' + \
                lista_humans[print3_humans].ljust(6)
    for prints in range(len(lista_humans)):
        print(item_str2)
        if print3_bots != len(lista_bots) - 1:
            print1_bots += 3
            print2_bots += 3
            print3_bots += 3
            print1_humans += 3
            print2_humans += 3
            print3_humans += 3
            item_str2 = "                                   " + lista_bots[print1_bots].ljust(13) + '   ' + lista_bots[
                print2_bots].ljust(15) + '   ' + lista_bots[print3_bots].ljust(6) + "||  " + \
                        lista_humans[print1_humans].ljust(13) + '   ' + lista_humans[print2_humans].ljust(15) + '   ' + \
                        lista_humans[print3_humans].ljust(6)
        else:
            break
def newRandomDNI():
    # Generate random 8-digit number
    dni_number = str(random.randint(10000000, 99999999))

    # Calculate letter for DNI
    letter_list = "TRWAGMYFPDXBNJZSQVHLCKE"
    dni_letter = letter_list[int(dni_number) % 23]

    return dni_number + dni_letter
def show_players():
    cont = 0
    for i in players:
        cont = cont + 1
        print(" " * 16, f"Player {cont}", " " * 16)
        print("NIF".ljust(20), str(i).rjust(20))
        print("Name".ljust(20), str(players[i]["name"]).rjust(20))
        print("-" * 41)
def menu_02():    #### MENU SETTINGS ####
    dejar_este_nivel = False
    while not dejar_este_nivel:
        opcion_ok = False
        opc = ''
        while not opcion_ok:
            print(menu02)
            opc = input("\n" + " " * 60 + "Option: " + "\n" + " " * 60 )
            if not opc.isdigit():
                print("== Opcion Incorrecta!!! ===")
            elif int(opc) < 1 or int(opc) > 4:
                print("== Opcion Incorrecta!!! ===")
            else:
                opcion_ok = True
                opc = int(opc)
        if opc == 1:
            print("Option 2.1 ")

        if opc == 2:
            print("Set Card's Deck (Default Spanish Deck)")

        if opc == 3:
            print("Max Rounds")
        if opc == 4:

            dejar_este_nivel = True



